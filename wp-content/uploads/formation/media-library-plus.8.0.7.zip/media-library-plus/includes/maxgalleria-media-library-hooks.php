<?php
//actions

//filters

if(!defined('MGMLP_FILTER_POST_TYPE_ARGS'))
  define('MGMLP_FILTER_POST_TYPE_ARGS', 'mg-media-library-plus_post_type_args');
if(!defined('MGMLP_FILTER_ADD_TOOLBAR_BUTTONS'))
  define('MGMLP_FILTER_ADD_TOOLBAR_BUTTONS', 'mgmlp_add_toolbar_buttons');
if(!defined('MGMLP_FILTER_ADD_TOOLBAR_AREAS'))
  define('MGMLP_FILTER_ADD_TOOLBAR_AREAS', 'mgmlp_add_toolbar_areas');

// still needed, filters for adding css files, js files that can be added to multiple times
// and for locaizing a script

?>
